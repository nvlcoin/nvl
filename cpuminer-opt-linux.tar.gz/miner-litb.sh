#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yespowerLITB -o stratum+tcp://stratum.rplant.xyz:7041 -u WALLET.WORKER_NAME
done
